package net.kathir.diffutilkotlin

data class Player(val id: Int, val name: String, val rating: Int, val yearOfBirth: Int)
