package net.kathir.diffutilkotlin;

public class PlayerAdapter {
}
