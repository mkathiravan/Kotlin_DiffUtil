package net.kathir.diffutilkotlin

class PlayerDiffCallback(private val oldList: List<Player>, private val newList: List<Player>)
{

}
